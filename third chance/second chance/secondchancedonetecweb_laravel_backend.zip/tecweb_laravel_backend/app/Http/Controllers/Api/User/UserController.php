<?php

namespace App\Http\Controllers\Api\User;

//Helpers and Class
use App\Exceptions\ApiValidatorException;
use Validator;
//Models
use Carbon\Carbon;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
//use App\Models\Passport\Token;
/*use App\Models\DeviceLogger;
use App\Models\Device;*/
//Class
use MongoDB\BSON\UTCDateTime;
use App\Http\Facades\Utilities;
use App\Models\Pdf;
use Illuminate\Http\Request;
use App\Http\Traits\ResponseApi;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Auth;


//use Illuminate\Support\Facades\Mail;
//use App\Mail\NotificationRegister;


class UserController extends Controller
{
    use ResponseApi;
    public function register (Request $request) 
    {
        try {
            $input = $request->all();
            $rules = [
                'email' => 'required|string',
                'id' => 'required|string',
                'folio' => 'required|string'
            ];
            $input['folio'] = Hash::make($input['folio']);
            //Hash::check()

            $validator = Validator::make($input, $rules);
            if ($validator->fails()) return $this->sendError($validator->errors()->all(),str_replace(':attribute','email',trans('validation.email')), 422);

            $user = DB::connection('mysql')->table('User')->where('id',$input['id'])->where('email',$input['email'])->first();
            Log::info('woola');
            Log::info($input);
            // $user = User::where('id', $input['id'])->first();
            if (!empty($user))  throw new ApiValidatorException('The email is already in db',trans('user.register.duplicate'), 409);

            //DB::connection('mysql')->table('User')->insert($input);

            
            $user = User::create($input);
           // $user = new User();
           // $user->fill($input);       
            //$user->save();

                /*
            dispatch(function () use ($user,$password) {
                $subject='Registro éxitoso Safe App Master';
                Mail::to($user->email)->send(new NotificationRegister($user ,$password, $subject));
            })->afterResponse();*/

            return $this->sendResponse($this->createAccesTokenResponse($user), trans('usuario creado con éxito'));
        } catch (ApiValidatorException $th) {
            return $this->sendError($th->getError(), $th->getMessage(), $th->getCode());
        }
    }

    public function login(Request $request)
    {

        $rules = array(
            'id' => array('required'),
            'folio' => array('required'),
        );

        $input = $request->all();
        //dd($input);
        $validator = Validator::make($input, $rules);

        if ($validator->fails()) {
            return $this->sendError('Validator', $validator->errors()->all(), 422);
        }

        $user = $this->userAuthentication($input['id'], $input['folio']);

        //dd($admin);
        if (!$user) {
            return $this->sendError('Authentication', trans('No se encontró usuario'), 403);
        }

        return $this->sendResponse($this->createAccesTokenResponse($user), trans('usuario Autenticado con éxito'));

    }


    private function userAuthentication($id, $folio)
    {

      /*  $credentials = [
            'id' => $id,
            'folio' => $folio,
        ];*/
        //dd($credentials);
        //dd($credentials);
        $user = User::where('id',$id)->first();
        Log::info('HOLAA');

        Log::info($user->id);
        return $user && Hash::check($folio, $user->folio) ? $user : false;
    }
    
    /**
     * Get User information.
     *
     * @return \Illuminate\Http\Response
     */
    

    public function createAccesTokenResponse($user)
    {
        $token = $user->createToken('auth_token')->plainTextToken;
            
        return [
            'access_token' => $token,
            'token_type' => 'Bearer'
            //'expires_at' => Carbon::parse($tokenResult->token->expires_at)->toDateTimeString()
        ];
    }


    public function logout()
    {
        auth()->user()->tokens()->delete();
            
        return $this->sendResponse('loggout success', trans('usuario deslogueado con éxito'));

    }
}